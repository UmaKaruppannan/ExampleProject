package com.cg.dao;

import com.cg.entities.Patient;
import com.cg.exception.PatientException;



public interface IPatientDao 
{
	public int addPatient(Patient patient) throws PatientException;

}
