package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entities.Patient;
import com.cg.exception.PatientException;



@Repository("patientDao")
public class PatientDaoImpl implements IPatientDao
{

	@PersistenceContext
	private EntityManager entityManager;
	
	public PatientDaoImpl()
	{
		
	}
	
	
	@Override
	public int addPatient(Patient patient) throws PatientException {
	
		{	
			int Patient_id = 0;
			try
			{
				
					entityManager.persist(patient);
					Patient_id =   patient.getPatient_id();
				
				
			}
			catch(Exception e)
			{
			
				throw new PatientException(e.getMessage());
			}
			
			return Patient_id;
		}
	}
}