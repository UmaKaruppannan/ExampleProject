package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;


@Entity
@Table(name="PatientDetails")	//if table name are not matching
@NamedQueries(
@NamedQuery(name="getAllPatient",query="Select p from Patient p"))
@Component("patient ")
public class Patient 
{
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseqgen")		//to auto generate id.
	@SequenceGenerator(name="myseqgen" ,sequenceName="Patient_Id",initialValue=1000)
	@Column(name="patient_id")
	private int patient_id;
	
	
	@NotEmpty(message="Name cannotbe empty")
	@Column(name="patient_name" , nullable=false)
	private String patient_name;
	
	
	
	private int age;
	
	
	
	private long phone;
	

	
	private String description;
	
	
	
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Patient(int patient_id, String patient_name, int age, long phone,
			String description) {
		super();
		this.patient_id = patient_id;
		this.patient_name = patient_name;
		this.age = age;
		this.phone = phone;
		this.description = description;
	}



	@Override
	public String toString() {
		return "Patient [patient_id=" + patient_id + ", patient_name="
				+ patient_name + ", age=" + age + ", phone=" + phone
				+ ", description=" + description + "]";
	}



	public int getPatient_id() {
		return patient_id;
	}



	public void setPatient_id(int patient_id) {
		this.patient_id = patient_id;
	}



	public String getPatient_name() {
		return patient_name;
	}



	public void setPatient_name(String patient_name) {
		this.patient_name = patient_name;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public long getPhone() {
		return phone;
	}



	public void setPhone(long phone) {
		this.phone = phone;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + patient_id;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Patient other = (Patient) obj;
		if (patient_id != other.patient_id)
			return false;
		return true;
	}
	
	

}
