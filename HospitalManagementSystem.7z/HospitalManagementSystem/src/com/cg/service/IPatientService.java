package com.cg.service;

import com.cg.entities.Patient;
import com.cg.exception.PatientException;

public interface IPatientService 
{
	public int addPatient(Patient patient) throws PatientException;

}
