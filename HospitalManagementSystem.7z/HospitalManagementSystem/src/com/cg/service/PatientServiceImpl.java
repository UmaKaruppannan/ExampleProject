package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IPatientDao;
import com.cg.entities.Patient;
import com.cg.exception.PatientException;


@Transactional
@Service("patientService")
public class PatientServiceImpl implements IPatientService {
	
	@Autowired
	IPatientDao patientDao ;
	public PatientServiceImpl() 
	{
		
	}
	
	public IPatientDao getPatientDao() {
		return patientDao;
	}

	public void setPatientDao(IPatientDao patientDao) {
		this.patientDao = patientDao;
	}

	public PatientServiceImpl(IPatientDao patientDao) {
		super();
		this.patientDao = patientDao;
	}

	@Override
	public int addPatient(Patient patient) throws PatientException {
		
		return patientDao.addPatient(patient);
	}

}
