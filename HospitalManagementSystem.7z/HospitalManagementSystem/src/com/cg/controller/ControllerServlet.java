
package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entities.Patient;

import com.cg.service.IPatientService;




@Controller
public class ControllerServlet
{
	
	@Autowired
	IPatientService patientService;

	public ControllerServlet() {
		super();
		
	}

	public IPatientService getPatientService() {
		return patientService;
	}

	public void setPatientService(IPatientService patientService) {
		this.patientService = patientService;
	}
	
	
	@RequestMapping("home")
	public String getHomePage()
	{
		return "HomePage";
	}
	
	@RequestMapping("addpatient")
	public String getAddPatient(Model model)
	{
		
		//init the date for category drop down list
		List<String> categories = new ArrayList();
		categories.add("Operation");
		categories.add("General");
		categories.add("Checkup");

		
		//Add the form backing bean to be binded to AddProduct.jsp Form
		model.addAttribute("patient", new Patient());
		
		//Add categories to build the drop down list in AddProduct dynamically
		model.addAttribute("categories",categories);
		
		//Return view name
		return "AddPatient";
	}
	
	
	@RequestMapping(value="processAdd")
	public ModelAndView processAdd
		(@ModelAttribute("patient") @Valid Patient patient,
		BindingResult result, Model model)
	{
		if (result.hasErrors() == true)
		{
			//init the date for category drop down list
			List<String> categories = new ArrayList();
			categories.add("Operation");
			categories.add("General");
			categories.add("Checkup");

			
			//Add the form backing bean to be binded to AddProduct.jsp Form
			model.addAttribute("patient", new Patient());
			
			//Add categories to build the drop down list in AddProduct dynamically
			model.addAttribute("categories",categories);
			
			
			return new ModelAndView("AddPatient");
		}
		
		 int Patient_id = -1;
		 try
			{
			 	Patient_id = patientService.addPatient(patient);
				 model.addAttribute("message", "Patient Added Successfully. Patient_id:"+ Patient_id);
				 return new ModelAndView("SuccessPage");
			} 
		 
		catch (Exception e)
		 
			{
				model.addAttribute("errorMsg", "Could not add patient"
						+ ". Reason"+ e.getMessage());
				return new ModelAndView("ErrorPage");
			}
		
	}
	
	


}
